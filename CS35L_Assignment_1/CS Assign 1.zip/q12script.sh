#!/bin/bash

ps -e -f -j -H
